<?php
// Include the configuration file  
require_once './config.php';

// Include the database connection file  
require_once './../connect.php';

// display error 
ini_set('display_errors', 1);
error_reporting(E_ALL);



$payment_ref_id = $statusMsg = '';
$status = 'error';

// Check whether the payment ID is not empty 
if (!empty($_GET['checkout_ref_id'])) {
    $payment_txn_id  = base64_decode($_GET['checkout_ref_id']);

    // Fetch transaction data from the database 
    $sqlQ = "SELECT * FROM all_members WHERE transaction_id = ?";
    $stmt = $pdo->prepare($sqlQ);
    $stmt->bindParam(1, $payment_txn_id, PDO::PARAM_STR);
    $stmt->execute();
    $stmt->rowCount();

    echo $stmt->rowCount();


    if ($stmt->rowCount() > 0) {
        // Get transaction details 
        $paymentData = $stmt->fetch(PDO::FETCH_ASSOC);
        header("Location: ./../paypal_success.php");
        $status = 'success';
        
    } else {
        $statusMsg = "Transaction has been failed!";
        header("Location: ./../cancel.php");
    }
} else {
    
    exit;
}